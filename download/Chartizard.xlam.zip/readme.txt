Thanks for trying out Chartizard, a chart wizard.

There is a comprehensive tutorial that introduces you step by step through installation and use: tutorial\TUTORIAL.xlsx

But if you don't have time, TL;DR:

	- Chartizard is an xlam addon – once installed to Excel, it will work in background.

	- How to install:
		Step 1: place the Chartizard.xlam file in the following folder %AppData%/Microsoft/AddIns
		Step 2: enable the addin in "Excel Add-ins" dialogue

	- Quick guide:
		Shortcut Macros:
			Ctrl+Shift+N    gets ID of selected chart into the last active cell
			Ctrl+Shift+J    select the chart with ID from active cell
			Ctrl+Shift+R    rename selected chart via textbox
			Ctrl+Shift+D    when chart ID is selected, all data series will be written below
			Ctrl+Shift+E    execute all ::functions in selection, those are prepared by the UDFs

		User defined functions (UDFs):
			getRGB          Create usable color number from RGB values
			createSeries    Create usable SERIES string that can be inserted manually or using setChartSeries or addChartSeries
			createAddress   Simple way to make dynamically updating range, basically a more powerful extension of Excel address
			createHLine     Create usable SERIES string to make horizontal line (useful to mark a constant limit value)
			createVLine     Create usable SERIES string to make vertical line (useful to mark a time event)
			setChartSeries  Update (overwrite) selected chart with data series (for repeated use to update)
			addChartSeries  Add (append) a single series to selected chart (for single time use)
			selectAxis      Choose primary/secondary Y axis for selected series
			setAxisBounds   Set/unset bounds and major step of all axes for selected chart
			setAxisFormat   Set number formats of all axes for selected chart
			setLineStyle    Set style of line and marker for selected series
			setChartSize    Set size of a selected embedded chart
			setChartTitles  Set/delete titles for the chart itself and all the axes

Made by Jiří Zbytovský in 2022 under MIT license (see license.txt)
